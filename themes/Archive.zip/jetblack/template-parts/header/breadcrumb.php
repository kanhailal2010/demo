<?php
/**
 * Displays breadcrumb
 *
 * @package JetBlack
 */

jetblack_breadcrumb();
